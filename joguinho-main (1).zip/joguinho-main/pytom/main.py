
print("----------")
print("Bm vindo ao jogo")
print("----------")


n_secreto = 100
entrada = int(input("Digite um número: "))
acerto = entrada == n_secreto
entrada_maior = entrada > n_secreto
entrada_menor = entrada < n_secreto

print(f"Você digitou o número: {entrada}")


if(Acertou):
    print(Você conseguiu)
if(entrada == n_secreto):
    print(f"Você Acertou")
else:
    if(entrada > n_secreto):
        print("o numero é menor em")
    if(entrada < n_secreto):
        print("o numero a maior que isso")

print("Fim de Jogo")
