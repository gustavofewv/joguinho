variavel = "uma variavel não precisa ; no final"

print(variavel)
variavel2 = 500
variavel3 = 30.5
variavel4 = True
print(type(variavel),type(variavel2),type(variavel3),type(variavel4))


input("digite um valor aleatorio:")